This is where your .tff and .otf font files go.

Fonts can be set to texts in lua with:
setTextFont(tag, font)